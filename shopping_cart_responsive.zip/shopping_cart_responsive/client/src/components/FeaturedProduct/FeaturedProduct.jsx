import React , { useEffect , useState}from 'react'
import axios from 'axios';
import Card from '../Card/Card'
import "./FeaturedProducts.scss"
import useFetch from '../../hooks/useFetch';

const FeaturedProduct = ({type}) => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(false)
    useEffect(() => {
     const fetchData = async() => {
        try {
          setLoading(true);
            const res = await axios.get(process.env.REACT_APP_API_URL + `/products?populate=*` , 
            {
                headers: {
                    Authorization : "bearer " + process.env.REACT_APP_API_TOKEN 
                }
            });   
            setData(res.data.data)
            setLoading(false);
        } catch (error) {
          setError(true)
            console.log("error" , error)
        }
     }
     fetchData();
    }, [])


    // const {data , loading , error} = useFetch(`/products?populate=*&[filters][type][$eq]=${type}`)
    // console.log("data__featureproducts" , data)
    return (
        <div className='featuredProducts'>
            <div className="top">
                <h1>{type} products</h1>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolor, libero! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima, ipsa?</p>
            </div>
            <div className="bottom">
                {loading ? "Loading..." : error ? "Something went wrong." : data.map(item => (
                    <Card item={item} key={item.id}/>
                ))}
            </div>
        </div>
    )
}

export default FeaturedProduct
