import React from 'react'
import "./Home.scss"
import Slider from '../../components/Slider/Slider'
import Categories from '../../components/Categories/Categories'
import Contact from '../../components/Contact/Contact'
import FeaturedProduct from '../../components/FeaturedProduct/FeaturedProduct'


const Home = () => {
  return (
    <div className='home'>
     <Slider />
    <FeaturedProduct type="Featured"/>
     <Categories />
     <FeaturedProduct type="Trending" />
     <Contact />
    </div>
  )
}

export default Home
